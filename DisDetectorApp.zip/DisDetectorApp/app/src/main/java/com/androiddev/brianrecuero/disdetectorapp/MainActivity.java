package com.androiddev.brianrecuero.disdetectorapp;

/*Author: Brian J. Recuero
* Date: 10/1/17
* Program Name: Dis Detector
* This program uses Meaning Cloud's Sentiment Analysis API:
* Sentiment Analysis is MeaningCloud's solution for performing a detailed multilingual sentiment analysis of texts from different sources.
* The text provided is analyzed to determine if it expresses a positive/negative/neutral sentiment; to do this, the local polarity of the different
* sentences in the text is identified and the relationship between them evaluated, resulting in a global polarity value for the whole text.*/


import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

import static android.view.View.*;

public class MainActivity extends AppCompatActivity {
    /*Initializing the variables*/
    private ProgressBar loading;
    private String input;
    private Button search;
    private TextView results;
    private EditText input2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {//............................................OnCreate
        super.onCreate(savedInstanceState);
        /*Setting Up Variables and Views*/
        setContentView(R.layout.activity_main);
        loading =(ProgressBar)findViewById(R.id.progressBar);
        loading.setVisibility(GONE);
        input = new String ("NO Imput");
        input2=(EditText)findViewById(R.id.addDis);
        results=((TextView) findViewById(R.id.displayDis));
    }

    public void search(View v){//.....................................................................On Click Button Function
        loading.setVisibility(VISIBLE);

        Uri builtUri2= Uri.parse("http://api.meaningcloud.com/sentiment-2.1"
        ).buildUpon()
                .appendQueryParameter("key","fa83da907198503b6449328ba63ee1c6")
                .appendQueryParameter("txt", input2.getText().toString())
                .appendQueryParameter("lang","en")
                .build();
        /*This is creates an anonymous instance and call the AsyncTask, which will
        * explicitly start doInBackGround when we execute. DO tgus after we create
        * the FindSentimentTask method below. We made this anonymus because we're
        * not going to use this instance agian.
        * Anonymous means we cant refer to it agian.
         */
        new FindSentimentTask().execute(builtUri2.toString());


        //builtUri2.toString();
        results.setText("");

    }
    //Must right click and click implement methods
    public class FindSentimentTask extends AsyncTask<String, Void, String> {



        @Override
        protected String doInBackground(String... url) {


            String toReturn= "DID NOT WORK";
            try
            {

                toReturn=getResponseFromHttpUrl(url[0]);


            }catch (Exception e)
            {
             // Log.d("ErrorInApp”,"exception on get Response from HTTP call " + e.getMessage());
                return toReturn;
            }
            //this return val goes to on post execute
            return toReturn;
        }
        protected void onPostExecute(String sentimentData) {
            /*P+: strong positive
            P: positive
            NEU: neutral
            N: negative
            N+: strong negative
            NONE: without sentiment*/
            try {
                loading.setVisibility(INVISIBLE);
                JSONObject sentimentJSON = new JSONObject(sentimentData);

                String irony= sentimentJSON.get("irony").toString();
                String confidence= sentimentJSON.get("confidence").toString();


                String scoreTag = sentimentJSON.get("score_tag").toString();

                if(scoreTag.contains("P+")&&!scoreTag.contains("P")) {

                results.setText("ScoreTag: strong positive"+"\n"+"Confidence: "
                        +confidence+"\n"+"Irony: "+irony);

                }else if(scoreTag.contains("P")&&!scoreTag.contains("P+")){

                    results.setText("ScoreTag: Positive"+"\n"+"Confidence: "
                            +confidence+"\n"+"Irony: "+irony);

                }else if(scoreTag.contains("NEU")){

                    results.setText("ScoreTag: Neutral"+"\n"+"Confidence: "
                            +confidence+"\n"+"Irony: "+irony);

                }else if(scoreTag.contains("N")&& !scoreTag.contains("NONE")){


                    results.setText("ScoreTag: Negative"+"\n"+"Confidence: "
                            +confidence+"\n"+"Irony: "+irony);
                }else if(scoreTag.contains("N+")&& !scoreTag.contains("NONE")) {

                    results.setText("ScoreTag: Strong Negative"+"\n"+"Confidence: "
                            +confidence+"\n"+"Irony: "+irony);

                }else {
                    results.setText("ScoreTag: Without Sentiment"+"\n"+"Confidence: "
                            +confidence+"\n"+"Irony: "+irony);
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }
    public static String getResponseFromHttpUrl(String url) throws IOException {
        URL theURL = new URL(url);
        HttpURLConnection urlConnection = (HttpURLConnection) theURL.openConnection();
        try {
            InputStream in = urlConnection.getInputStream();

            Scanner scanner = new Scanner(in);
            scanner.useDelimiter("\\A");

            boolean hasInput = scanner.hasNext();
            if (hasInput) {
                //Next Returns the String
                return scanner.next();
            } else {
                return null;
            }
        } finally {
            urlConnection.disconnect();
        }
    }
}//end of main


